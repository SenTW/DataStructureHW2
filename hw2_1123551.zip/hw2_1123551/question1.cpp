// Sen
// 1123551
// 24.11.27

#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
#include <sstream>
using namespace std;


struct TreeNode
{
    int v;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : v(x), left(nullptr), right(nullptr) {}
};

// Function to build a binary tree from level-order input
TreeNode *buildTree(vector<int> &level)
{
    if (level.empty() || level[0] == -1)
        return nullptr;

    TreeNode *root = new TreeNode(level[0]);
    queue<TreeNode *> q;
    q.push(root);
    int i = 1;

    while (!q.empty() && i < level.size())
    {
        TreeNode *current = q.front();
        q.pop();

        // Process left
        if (level[i] != -1)
        {
            current->left = new TreeNode(level[i]);
            q.push(current->left);
        }
        i++;

        // Process right
        if (i < level.size() && level[i] != -1)
        {
            current->right = new TreeNode(level[i]);
            q.push(current->right);
        }
        i++;
    }

    return root;
}

// Function to calculate the diameter and height of the tree
int calculateDiameter(TreeNode *root, int &diameter)
{
    if (!root)
        return 0;

    int leftHeight = calculateDiameter(root->left, diameter);
    int rightHeight = calculateDiameter(root->right, diameter);

    diameter = max(diameter, leftHeight + rightHeight);

    return 1 + max(leftHeight, rightHeight);
}

// Function to calculate the diameter of the tree
int findDiameter(TreeNode *root)
{
    int diameter = 0;
    calculateDiameter(root, diameter);
    return diameter;
}

int main()
{
    cout << "Enter level-order traversal (use -1 for null nodes, space-separated): ";
    string inputLine;
    getline(cin, inputLine);
    vector<int> level;
    int num;
    stringstream ss(inputLine);

    while (ss >> num)
        level.push_back(num);

    TreeNode *root = buildTree(level);
    int diameter = findDiameter(root);
    cout << "Diameter of the binary tree: " << diameter << endl;

    return 0;
}
