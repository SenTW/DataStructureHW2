// Sen
// 1123551
// 24.11.27

#include <bits/stdc++.h>
using namespace std;

struct Task {
    string name;
    int priority;

    Task(string task_name, int task_priority) {
        name = task_name;
        priority = task_priority;
    }

    bool operator<(const Task &other) const {
        return priority < other.priority;
    }
};

// Number of operations

int main() {
    int N;
    cout << "Enter the number of operations: ";
    cin >> N;

// Priority queue
    priority_queue<Task> pq;

    vector<string> get_results; // To store output of all GET operations

    // Process each operation
    cout << "Enter operations" << endl;
    for (int i = 0; i < N; ++i) {
        string operation;
        cin >> operation;

        if (operation == "ADD") {
            string task_name;
            int priority;
            cin >> task_name >> priority;
            pq.push(Task(task_name, priority));
        } else if (operation == "GET") {
            if (!pq.empty()) {
                Task top_task = pq.top();             // Get the highest priority task
                get_results.push_back(top_task.name); // Store the task name in output
                pq.pop();                             // Remove the task from the heap
            } else {
                get_results.push_back("No tasks available"); // If no tasks available
            }
        } else {
            cout << "Invalid operation. Use 'ADD' or 'GET'." << endl;
        }
    }

    cout << "--------- Results ---------" << endl;

    // Output all GET operations
    for (const string &result : get_results) {
        cout << result << endl;
    }

    cout << "Remaining tasks: ";
    vector<pair<string, int>> remaining_tasks;

    while (!pq.empty()) {
        Task task = pq.top();
        remaining_tasks.push_back({task.name, task.priority});
        pq.pop();
    }

    // Output remaining tasks
    cout << "[";
    for (size_t i = 0; i < remaining_tasks.size(); ++i) {
        if (i > 0) cout << ", ";
        cout << "('" << remaining_tasks[i].first << "', " << remaining_tasks[i].second << ")";
    }
    cout << "]" << endl;

    return 0;
}
