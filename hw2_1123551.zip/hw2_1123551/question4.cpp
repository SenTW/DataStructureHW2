// Sen
// 1123551
// 24.11.27

#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

struct Task {
    int profit;
    int deadline;

    // Comparator for the max-heap
    bool operator<(const Task& other) const {
        return profit < other.profit;  // Max heap based on profit
    }
};

// Function to schedule tasks for maximum profit, sort tasks based on profit in descending order
pair<int, vector<int>> scheduleTasks(vector<Task>& tasks) {
    sort(tasks.begin(), tasks.end(), [](const Task& a, const Task& b) {
        return a.profit > b.profit;
    });

    // Find the maximum deadline to determine the number of available slots
    int maxDeadline = 0;
    for (const auto& task : tasks) {
        maxDeadline = max(maxDeadline, task.deadline);
    }

    // Create a vector to track the available slots
    vector<int> slots(maxDeadline + 1, -1);

    int totalProfit = 0;
    vector<int> scheduledTasks;

    for (const auto& task : tasks) {
        // Try to find an available slot before or on the task's deadline
        for (int i = task.deadline; i > 0; --i) {
            if (slots[i] == -1) {
                slots[i] = task.profit;
                totalProfit += task.profit;
                scheduledTasks.push_back(task.profit);
                break;
            }
        }
    }

    return {totalProfit, scheduledTasks};
}

int main() {
    int n;
    cin >> n;

    vector<Task> tasks(n);

    for (int i = 0; i < n; ++i) {
        cin >> tasks[i].profit >> tasks[i].deadline;
    }
    auto [maxProfit, scheduledTasks] = scheduleTasks(tasks);

    // Output
    cout << "Maximum Profit: " << maxProfit << endl;
    cout << "Scheduled Tasks: [";
    for (size_t i = 0; i < scheduledTasks.size(); ++i) {
        cout << scheduledTasks[i];
        if (i != scheduledTasks.size() - 1) cout << ", ";
    }
    cout << "]" << endl;

    return 0;
}
