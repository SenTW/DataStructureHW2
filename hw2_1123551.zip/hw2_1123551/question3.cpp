// Sen
// 1123551
// 24.11.27

#include <iostream>
#include <vector>
#include <queue>
#include <functional>

using namespace std;

    // Storing data
struct Element {
    int value;
    int arrayIndex;
    int elementIndex;

    // Comparator for the priority queue
    bool operator>(const Element& other) const {
        return value > other.value;
    }
};

// Function to merge K sorted arrays using a min heap
    vector<int> mergeKSortedArrays(const vector<vector<int>>& arrays) {
    vector<int> result;
    priority_queue<Element, vector<Element>, greater<Element>> minHeap;

    // Insert the first element of each array into the min heap
    for (int i = 0; i < arrays.size(); ++i) {
        if (!arrays[i].empty()) {
            minHeap.push(Element{arrays[i][0], i, 0});
        }
    }

    // Extract the smallest element from the heap and insert the next element from the same array
    while (!minHeap.empty()) {
        Element curr = minHeap.top();
        minHeap.pop();
        result.push_back(curr.value);

        if (curr.elementIndex + 1 < arrays[curr.arrayIndex].size()) {
            minHeap.push(Element{
                arrays[curr.arrayIndex][curr.elementIndex + 1],
                curr.arrayIndex,
                curr.elementIndex + 1
            });
        }
    }

    return result;
}

int main() {
    int k;
    cin >> k;

    vector<vector<int>> arrays(k);

    // Input the K sorted arrays and read the number of elements in the current array
    for (int i = 0; i < k; ++i) {
        int n;
        cin >> n;
        arrays[i].resize(n);
        for (int j = 0; j < n; ++j) {
            cin >> arrays[i][j];
        }
    }

    // Merge the arrays and output a merged one
    vector<int> mergedArray = mergeKSortedArrays(arrays);
    cout << "Merged Array: ";
    for (int i = 0; i < mergedArray.size(); ++i) {
        cout << mergedArray[i] << " ";
    }
    cout << endl;

    return 0;
}
